package com.example.laboratorium3

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.ToggleButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var AND_X0: ToggleButton
    lateinit var AND_X1: ToggleButton
    lateinit var OR_X0: ToggleButton
    lateinit var OR_X1: ToggleButton
    lateinit var NAND_X0: ToggleButton
    lateinit var NAND_X1: ToggleButton
    lateinit var NOR_X0: ToggleButton
    lateinit var NOR_X1: ToggleButton
    lateinit var XOR_X0: ToggleButton
    lateinit var XOR_X1: ToggleButton
    lateinit var XNOR_X0: ToggleButton
    lateinit var XNOR_X1: ToggleButton

    lateinit var AND_Y: TextView
    lateinit var NAND_Y: TextView
    lateinit var OR_Y: TextView
    lateinit var NOR_Y: TextView
    lateinit var XOR_Y: TextView
    lateinit var XNOR_Y: TextView

    var AND_X0_var = false
    var AND_X1_var = false

    var NAND_X0_var = false
    var NAND_X1_var = false

    var OR_X0_var = false
    var OR_X1_var = false

    var NOR_X1_var = false
    var NOR_X0_var = false

    var XNOR_X0_var = false
    var XNOR_X1_var = false

    var XOR_X0_var = false
    var XOR_X1_var = false


    fun updateAND() {
        if (AND_X0_var && AND_X1_var == true){
            AND_Y.text = "1"
        }else{
            AND_Y.text = "0"
        }
    }

    fun updateNAND(){
        if (NAND_X0_var && NAND_X1_var == true){
            NAND_Y.text = "0"
        }else{
            NAND_Y.text = "1"
        }
    }

    fun updateOR(){
        if (!OR_X0_var && !OR_X1_var){
            OR_Y.text = "0"
        }else{
            OR_Y.text = "1"
        }
    }

    fun updateNOR(){
        if(!NOR_X0_var && !NOR_X1_var){
            NOR_Y.text = "1"
        }else{
            NOR_Y.text = "0"
        }
    }

    fun updateXOR(){
        if (XOR_X0_var && XOR_X1_var || !XOR_X0_var && !XOR_X1_var){
            XOR_Y.text = "0"
        }else{
            XOR_Y.text = "1"
        }
    }

    fun updateXNOR(){
        if (XNOR_X0_var && XNOR_X1_var || !XNOR_X0_var && !XNOR_X1_var){
            XNOR_Y.text = "1"
        }else{
            XNOR_Y.text = "0"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        AND_X0 = findViewById<ToggleButton>(R.id.tbAND_X0)
        AND_X1 = findViewById<ToggleButton>(R.id.tbAND_X1)
        NAND_X0 = findViewById<ToggleButton>(R.id.tbNAND_X0)
        NAND_X1 = findViewById<ToggleButton>(R.id.tbNAND_X1)
        OR_X0 = findViewById<ToggleButton>(R.id.tbOR_X0)
        OR_X1 = findViewById<ToggleButton>(R.id.tbOR_X1)
        NOR_X0 = findViewById(R.id.tbNOR_X0)
        NOR_X1 = findViewById(R.id.tbNOR_X1)
        XOR_X0 = findViewById(R.id.tbXOR_X0)
        XOR_X1 = findViewById(R.id.tbXOR_X1)
        XNOR_X0 = findViewById(R.id.tbXNOR_X0)
        XNOR_X1 = findViewById(R.id.tbXnOR_X1)


        AND_Y = findViewById<TextView>(R.id.tvAND_Y)
        NAND_Y = findViewById<TextView>(R.id.tvNAND_Y)
        OR_Y = findViewById<TextView>(R.id.tvOR_Y)
        NOR_Y = findViewById<TextView>(R.id.tvNOR_Y)
        XOR_Y = findViewById(R.id.tvXOR_Y)
        XNOR_Y = findViewById(R.id.tvXNOR_Y)

        AND_X0.setOnClickListener(View.OnClickListener{
            AND_X0_var = AND_X0.isChecked
            updateAND()
        })

        AND_X1.setOnClickListener(View.OnClickListener{
            AND_X1_var = AND_X1.isChecked
            updateAND()
        })

        NAND_X0.setOnClickListener(View.OnClickListener {
            NAND_X0_var = NAND_X0.isChecked
            updateNAND()
        })

        NAND_X1.setOnClickListener(View.OnClickListener {
            NAND_X1_var = NAND_X1.isChecked
            updateNAND()
        })

        OR_X0.setOnClickListener(View.OnClickListener {
            OR_X0_var = OR_X0.isChecked
            updateOR()
        })

        OR_X1.setOnClickListener(View.OnClickListener {
            OR_X1_var = OR_X1.isChecked
            updateOR()
        })

        NOR_X0.setOnClickListener(View.OnClickListener {
            NOR_X0_var = NOR_X0.isChecked
            updateNOR()
        })

        NOR_X1.setOnClickListener(View.OnClickListener {
            NOR_X1_var = NOR_X1.isChecked
            updateNOR()
        })

        XOR_X0.setOnClickListener(View.OnClickListener {
            XOR_X0_var = XOR_X0.isChecked
            updateXOR()
        })

        XOR_X1.setOnClickListener(View.OnClickListener {
            XOR_X1_var = XOR_X1.isChecked
            updateXOR()
        })

        XNOR_X0.setOnClickListener(View.OnClickListener {
            XNOR_X0_var = XNOR_X0.isChecked
            updateXNOR()
        })

        XNOR_X1.setOnClickListener(View.OnClickListener {
            XNOR_X1_var = XNOR_X1.isChecked
            updateXNOR()
        })
    }
}