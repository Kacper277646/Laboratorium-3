package com.example.laboratorium3

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val buttonAdd = findViewById<Button>(R.id.btAdd)
        val buttonSubstract = findViewById<Button>(R.id.btSubtract)
        val buttonClear = findViewById<Button>(R.id.btClear)
        val tvCounter = findViewById<TextView>(R.id.tvCounter)
        val tvText = findViewById<TextView>(R.id.tvText)

        var counter = 0

        buttonAdd.setOnClickListener{
            counter += 1
            tvCounter.text = counter.toString()
            if (tvText.text == "Wyzerowano")
                tvText.text = "Ilość wciśnięć = "
        }

        buttonSubstract.setOnClickListener{
            counter -= 1
            tvCounter.text = counter.toString()
            if (tvText.text == "Wyzerowano")
                tvText.text = "Ilość wciśnięć = "
        }

        buttonClear.setOnClickListener{
            counter = 0
            tvCounter.text = " "
            tvText.text = "Wyzerowano"

        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}